# Curios API and Accessories for Excalibur
══════════════════════════════════════════════════════════════════════════

  	This mod support was created and is maintained by ruseki_
        - You should have the Excalibur Resource Pack for this Add-On Pack to blend properly.
        - Report bugs with the pack to @Ruseki in the Excalibur Discord Channel.
        - I will make updates to the pack as necessary and time allows.


    All credit to Maffhew for Excalibur
        - Download Excalibur (Maffhew)
            - [CurseForge](https://www.curseforge.com/minecraft/texture-packs/excalibur)
            - [Planet Minecraft](https://www.planetminecraft.com/texture-pack/excalibur/)
            - [Modrinth](https://modrinth.com/resourcepack/excal)


Special Thanks To:
══════════════════════════════════════════════════════════════════════════

    Maffhew     - For Excalibur and permission to maintain Curios Support
 TheIllusiveC4 	- For Curios API and permission to upload to Curseforge and Modrinth
 Blodhgarm      - For Accessories and permission to upload to Curseforge and Modrinth

Excalibur License:
══════════════════════════════════════════════════════════════════════════

    Excalibur by Matt Dillow (Maffhew) is licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.
    http://creativecommons.org/licenses/by-nc-nd/3.0/us/

    In other words:
    - You may not redistribute this pack and claim it as your own.
    - You may not redistribute this pack without a link to the official CurseForge or Planet Minecraft Excalibur page.
    - You may not put money-making links such as adf.ly with this work under any circumstances.
    - You may not use this work for commercial purposes.
    - You may not alter, transform, or build upon this work.

    Noncommercial Waiver
    - You may use this Resource Pack as a part of any Minecraft-related video including those which are created for commercial purposes or 
    are monetized by advertising, as long as there's a direct link to an official Excalibur download page.

    Any of the above conditions can be waived if you get permission from Maffhew.
    Discord: @maffhew
    

Curios API License:
══════════════════════════════════════════════════════════════════════════
- Author: TheIllusiveC4

   - Source: https://www.curseforge.com/minecraft/mc-mods/curios
   - License: GNU LESSER GENERAL PUBLIC LICENSE
   - This work is licensed under the GNU Lesser General Public License version 3 (LGPLv3).

This work is licensed under the GNU Lesser General Public License version 3 (LGPLv3). You are free to use, modify, and distribute this mod, provided that any modifications or derivatives also comply with the LGPLv3 terms.


Accessories License:
══════════════════════════════════════════════════════════════════════════
- Author: Blodhgarm

   - Source: https://www.curseforge.com/minecraft/mc-mods/accessories
   - License: MIT License
   - This work is licensed under the Massachusetts Institute of Technology.

This work is protected under the MIT License. The MIT License is known for its brevity and clarity. It grants permission to use, modify, and distribute the software, with the condition that the original copyright notice and the license text are retained in the redistributed software. 


----------------------

This project’s original content is released under the following license:
All Rights Reserved.
